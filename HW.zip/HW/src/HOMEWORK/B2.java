package HOMEWORK;
public class B2 {
    public static void main(String[] args) {
        System.out.println("1/" + (9 / 5));
        System.out.println("2/" + (695 % 20));
        System.out.println("3/" + (7 + 6 * 5));
        System.out.println("4/" + (7 * 6 + 5));
        System.out.println("5/" + (248 % 100 / 5));
        System.out.println("6/" + (6 * 3 - 9 / 4));
        System.out.println("7/" + ((5 - 7) * 4));
        System.out.println("8/" + (6 + (18 % (17 - 12))));
    }
}
